# Game Controls
Press WASD or Arrow Keys to move around.
Press R to restart.

# Game Goals
Get to the target!
- Moving cost you health, so get wood to replenish your health.
- Catch the current for a free-ride.
- Avoid the shark who will chase and eat you.