# Game Goals
- Get to the target! But first, find it in the map.
- Moving cost you health, so get wood to replenish your health.
- Catch the current for a free-ride.
- Avoid or shoot the shark who will chase and eat you.

# Game Controls
- Press WASD or Arrow Keys to move around.
- Press F to fire.
- Press Space to open/close map.
- Press R to restart current level.
- Press Esc to return to menu.
